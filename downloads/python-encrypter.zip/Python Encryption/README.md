# Python Encryption

Welcome to Python Encryption.

To use this, open main.py and you will select a file and asked wether you want to encrypt or decrypt the file.
You will then be asked for a password that will be hashed using a basic hashing method.
This will edit the file to its encrypted or decrypted version

**secretKey.py**

This encryption method will take a string and any number. The method will take each digit of the number and encrypt/decrypt in order. For example I encrypt “ab” with the shift of 24 I will get returned “cf”.
This is the main encryption used in the main.py file.

**_IMPORTANT_**

**This method is** **_NOT_** **a secure method for actual encryption or decryption. Use at your own risk**

**Might make unexpected/unreversable changes**

Contact me with any issues/reccomendations at odedconnect@gmail.com
